<?php
$servername = "localhost";
$username = "root"; // default username for localhost
$password = ""; // default password for localhost
$dbname = "admin authentication";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate input
    $regno=trim($_POST['regno']);
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

    if (!empty($regno) && !empty($name) && !empty($phone) && !empty($email) && !empty($password)) {
        // Prepare an SQL statement
        $stmt = $conn->prepare("INSERT INTO admin (regno,name, phone, email, password) VALUES (?,?, ?, ?, ?)");
        $stmt->bind_param("sssss",$regno ,$name, $phone, $email, $password);
        if ($stmt->execute()) {
         header("Location: admin/index.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
      
    }
}

// Close the connection
$conn->close();
?>
