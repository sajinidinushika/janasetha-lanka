<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "footer_form";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate input
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

  
        $stmt = $conn->prepare("INSERT INTO footer(name, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $email);
        if ($stmt->execute()) {
         header("Location: index.html");
            exit();
    
        // Close the statement
        $stmt->close();
    } else {
       
    }
}

// Close the connection
$conn->close();
?>
