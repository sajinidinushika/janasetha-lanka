<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "user message authentication";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate input
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $message =trim($_POST['message']);

  
        $stmt = $conn->prepare("INSERT INTO message (first_name, last_name , email, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $first_name, $last_name, $email, $message);
        if ($stmt->execute()) {
         header("Location: contact.html");
            exit();
    
        // Close the statement
        $stmt->close();
    } else {
       
    }
}

// Close the connection
$conn->close();
?>
