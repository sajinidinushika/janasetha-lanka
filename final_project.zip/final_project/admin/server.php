<?php
$name="";
$type="";
$price="";
$contact="";
$location="";
$id=0;
$edit_state=false;

$db=mysqli_connect('localhost','root','','admin_panel');

if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$type=$_POST['type'];
	$price=$_POST['price'];
	$contact=$_POST['contact'];
	$location=$_POST['location'];
  $query="INSERT INTO information(name,type,price,contact,location)VALUES('$name','$type','$price','$contact','$location')";
  mysqli_query($db,$query);
  header('location: create.php');
}
if(isset($_POST['update'])){
	$name=mysqli_real_escape_string($db, $_POST['name']);
	$type=mysqli_real_escape_string($db, $_POST['type']);
	$price=mysqli_real_escape_string($db, $_POST['price']);
	$contact=mysqli_real_escape_string($db, $_POST['contact']);
	$location=mysqli_real_escape_string($db, $_POST['location']);
	$id=mysqli_real_escape_string($db, $_POST['id']);

	mysqli_query($db, "UPDATE information SET name='$name', type='$type' , price='$price' , contact='$contact',location='$location' WHERE id=$id");
	header('location:create.php');
}
if(isset($_GET['delete'])){
  $id=$_GET['delete'];
  mysqli_query($db,"DELETE FROM information WHERE id=$id ");
  	header('location:create.php');
}
$results=mysqli_query($db,"SELECT * FROM information");



?>