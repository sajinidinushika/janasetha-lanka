<?php 
$name="";
$type="";
$price="";
$contact="";
$location="";
$id="";

$edit_state=false;
$db=mysqli_connect('localhost','root','','admin_panel');
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$type=$_POST['type'];
	$price=$_POST['price'];
	$contact=$_POST['contact'];
	$location=$_POST['location'];
	$query="INSERT INTO information(name,type,price,contact,location)VALUES('$name','$type' ,'$price','$contact','$location')";
	mysqli_query($db,$query);
	header('location:index.php');

}
$results=mysqli_query($db,"SELECT * from information");






?>