<?php
include('server.php');
if(isset($_GET['edit'])){
  $id =$_GET['edit'];
  $edit_state=true;
  $rec=mysqli_query($db,"SELECT * FROM information WHERE id =$id");
  $record=mysqli_fetch_array($rec);
  $name=$record['name'];
  $type=$record['type'];
  $price=$record['price'];
  $contact=$record['contact'];
  $location=$record['location'];
  $id=$record['id'];
}


?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="my logo.png">
  <title>janasethalanka/admin_panel</title>
  <style>
    .back {
      background-color: #50C878;
      border-radius: 10px;
    }
    .edit_button, .delete_button{
      border-radius: 10px;
	  border:none;
      color: white;
      padding: 5px 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      margin: 4px 2px;
      cursor: pointer;
    }

    .edit_button {
      background-color: #04AA6D;
    }
    .delete_button {
      background-color: #f44336;
    }

	.home , .logout {
  background-color: #1F51FF; 
  border: none;
  border-radius:10px;
  color: white;
  padding: 8px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.home {
  background-color: #1F51FF; 
  color: white; 
  border: 2px solid #FFC300;
}

.logout {
  background-color: #f44336; 
  color: white; 
  border: 2px solid #FFC300;
}
.back1{
	background-color:#FCF55F;
	padding-bottom:0px;
	height:110px;
	width:1000px;
	border:2px solid white;
	border-radius:20px;

}
.home , .add {
  background-color: #1F51FF; 
  border: none;
  border-radius:10px;
  color: white;
  padding: 8px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.home {
  background-color: #1F51FF; 
  color: white; 
  border: 2px solid #FFC300;
}

  .add {
  background-color: #f44336; 
  color: white; 
  border: 2px solid #FFC300;
}
</style>
</head>
<body>
<div class="back">
    <br>
    <center>
    <div class="back1"> <b><h1>Janasetha Lanka Pvt (Ltd)<h1><h2>Admin Panel</h2></b></div>
	  <img src="about2.png" heigth="260px" width="300px">

	  <br><br>
	<table border="2">
		<tr>
			<td>name</td>
			<th>address</th>
			<th>price</th>
			<th>contact</th>
			<th>location </th>
			<th colspan="2">actions</th>
		</tr>
		<?php while($row = mysqli_fetch_array($results)){ ?>
        <tr>
		     <td><?php echo $row['name'];?></td>
			<td><?php echo $row['type'];?></td>
			<td><?php echo $row['price'];?></td>
			<td><?php echo $row['contact'];?></td>
			<td><?php echo $row['location'];?></td>
			<td><a href="index.php?edit=<?php echo $row['id']; ?>"><button class="edit_button">Edit</button></a></td>
            <td><a href="server.php?delete=<?php echo $row['id']; ?>"><button class="delete_button">Delete</button></a></td>
		</tr>
		<?php }
		?>
</table><br><br>
<a href ="http://localhost/final_project/index.html"><button class="home">Home</button></a>
<a href="http://localhost/final_project/admin/index.php"<button class="add">Add new Worker</button></a><br><br>
</div>
</body>
</html>