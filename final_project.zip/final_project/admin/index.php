<?php
include('server.php');
if (isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $edit_state = true;
  $rec = mysqli_query($db, "SELECT * FROM information WHERE id = $id");
  $record = mysqli_fetch_array($rec);
  $name = $record['name'];
  $type = $record['type'];
  $price = $record['price'];
  $contact = $record['contact'];
  $location = $record['location'];
  $id = $record['id'];
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="my logo.png">
  <title>janasethalanka/admin_panel</title>
  <style>
    .back {
      background-color: #50C878;
      border-radius: 10px;
    }
    .edit_button, .delete_button{
      border-radius: 10px;
	  border:none;
      color: white;
      padding: 5px 10px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      margin: 4px 2px;
      cursor: pointer;
    }

    .edit_button {
      background-color: #04AA6D;
    }
    .delete_button {
      background-color: #f44336;
    }

	.home , .logout {
  background-color: #1F51FF; 
  border: none;
  border-radius:10px;
  color: white;
  padding: 8px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.home {
  background-color: #1F51FF; 
  color: white; 
  border: 2px solid #FFC300;
}

.logout {
  background-color: #f44336; 
  color: white; 
  border: 2px solid #FFC300;
}
.back1{
	background-color:#FCF55F;
	padding-bottom:0px;
	height:110px;
	width:1000px;
	border:2px solid white;
	border-radius:20px;

}
  </style>
</head>
<body>
  <div class="back">
    <br>
    <center>
    <div class="back1"> <b><h1>Janasetha Lanka Pvt (Ltd)<h1><h2>Admin Panel</h2></b></div>
	  <img src="about.png" heigth="300px" width="400px">

	  <br><br>
      <table border="2">
        <tr>
          <th>Name</th>
          <th>Type</th>
          <th>Price</th>
          <th>Contact</th>
          <th>Location</th>
          <th colspan="2">Action</th>
        </tr>
        <?php
        $results = mysqli_query($db, "SELECT * FROM information");
        while ($row = mysqli_fetch_array($results)) { ?>
          <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['type']; ?></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['contact']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><a href="index.php?edit=<?php echo $row['id']; ?>"><button class="edit_button">Edit</button></a></td>
            <td><a href="server.php?delete=<?php echo $row['id']; ?>"><button class="delete_button">Delete</button></a></td>
          </tr>
        <?php } ?>
      </table>
      <br><br>
      <form action="server.php" method="post">
        <input type="hidden" name="id" value="<?php echo isset($id) ? $id : ''; ?>">
        Name: <input type="text" name="name" value="<?php echo isset($name) ? $name : ''; ?>"><br><br>
        Type: <input type="text" name="type" value="<?php echo isset($type) ? $type : ''; ?>"><br><br>
        Per day price: <input type="text" name="price" value="<?php echo isset($price) ? $price : ''; ?>"><br><br>
        Contact: <input type="text" name="contact" value="<?php echo isset($contact) ? $contact : ''; ?>"><br><br>
        Location: <input type="text" name="location" value="<?php echo isset($location) ? $location : ''; ?>"><br><br>

	
        <input type="submit" name="<?php echo isset($edit_state) && $edit_state ? 'update' : 'submit'; ?>" value="<?php echo isset($edit_state) && $edit_state ? 'Update' : 'Submit'; ?>">
        <input type="reset" value="reset"><br>

      </form>
	  <br><br>
	  <a href ="http://localhost/final_project/index.html"><button class="home">Home</button></a>
	  <button class="logout">Log Out</button>
    </center>
    <br><br>
  </div>
</body>
</html>
