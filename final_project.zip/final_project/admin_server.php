<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin authentication";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            header("Location: http://localhost/final_project/admin/index.php");
            exit();
        } else {
            header("Location: admin_log.php");
            exit();
        }
    } else {
        echo "No user found with this email";
    }

    $stmt->close();
    $conn->close();
}
?>

