<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "checkout";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate input
    $c_fname = trim($_POST['c_fname']);
    $c_lname = trim($_POST['c_lname']);
    $c_address = trim($_POST['c_address']);
    $c_cardno = trim($_POST['c_cardno']);
    $c_exp = trim($_POST['c_exp']);
    $c_cvv = trim($_POST['c_cvv']);
    $c_email_address = trim($_POST['c_email_address']);

  
        $stmt = $conn->prepare("INSERT INTO details(c_fname, c_lname,c_address,c_cardno,c_exp,c_cvv,c_email_address) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssss", $c_fname, $c_lname,$c_address,$c_cardno,$c_exp,$c_cvv,$c_email_address);
        if ($stmt->execute()) {
         header("Location: thankyou.html");
            exit();
    
        // Close the statement
        $stmt->close();
    } else {
       
    }
}

// Close the connection
$conn->close();
?>
